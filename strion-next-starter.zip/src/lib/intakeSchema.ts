
export type Intent='Wealth'|'Healing'|'Clarity'|'Protection'|'Legacy'|'Other';
export type SpaceType='Home'|'Office'|'Studio'|'Hospitality'|'Sacred Space';
export interface IntakePayload{
  name:string; email:string; phone?:string; location?:string; birthdate?:string;
  intent:Intent[]; spaceType:SpaceType; placement:string; dimensions?:string;
  materials?:string[]; geometry?:string[]; budget?:string; timeframe?:string; notes?:string;
}
