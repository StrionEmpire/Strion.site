
import Link from 'next/link';
export function Hero(){
  return (
    <section className="section text-center">
      <h1 className="h1">Crafted by Vision. <span className="gold">Matter, Mastered.</span></h1>
      <p className="lead mt-5 max-w-3xl mx-auto">Energetic Crafting — geometry, metals, crystals, and wood aligned to elevate space.</p>
      <div className="mt-8 flex items-center justify-center gap-4">
        <Link href="/custom" className="btn">Start Your Design</Link>
        <Link href="/work" className="link">See the Work →</Link>
      </div>
    </section>
  );
}
