
'use client';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';

export function Header(){
  const pathname = usePathname();
  const NavLink = ({href, children}:{href:string; children:React.ReactNode}) => (
    <Link href={href} className={`px-3 py-2 rounded-lg hover:bg-zinc-800 ${pathname===href?'text-gold':'text-stone-200'}`}>{children}</Link>
  );
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-black/50 ring-1 ring-zinc-800">
      <div className="section flex items-center gap-6 py-4">
        <Link href="/" className="flex items-center gap-3">
          <Image src="/crest.svg" width={36} height={36} alt="Strion crest" />
          <span className="font-display tracking-wide text-xl">STRION</span>
        </Link>
        <nav className="ml-auto flex items-center gap-2 text-sm">
          <NavLink href="/work">Work</NavLink>
          <NavLink href="/custom">Custom</NavLink>
          <NavLink href="/atelier">Atelier</NavLink>
          <NavLink href="/about">About</NavLink>
          <NavLink href="/contact">Contact</NavLink>
        </nav>
        <Link href="/custom" className="btn ml-2 hidden md:inline-flex">Start Your Design</Link>
      </div>
    </header>
  );
}
