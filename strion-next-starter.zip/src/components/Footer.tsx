
import Image from 'next/image';
import Link from 'next/link';

export function Footer(){
  return (
    <footer className="mt-24 border-t border-zinc-800">
      <div className="section grid md:grid-cols-3 gap-8 items-start">
        <div className="flex items-center gap-3">
          <Image src="/sigil.svg" width={36} height={36} alt="Strion sigil" />
          <div>
            <div className="font-display text-lg">STRION</div>
            <div className="text-stone-400 text-sm">Every line, every layer, charged with intention.</div>
          </div>
        </div>
        <div className="text-stone-400 text-sm">
          <div><Link href="/privacy" className="link">Privacy</Link> · <Link href="/terms" className="link">Terms</Link></div>
          <div className="mt-2">© {new Date().getFullYear()} STRION.</div>
        </div>
        <div className="md:text-right">
          <Link href="/custom" className="btn">Start Your Design</Link>
        </div>
      </div>
    </footer>
  );
}
