
'use client';
import { useState } from 'react';
import { IntakePayload } from '@/lib/intakeSchema';

export default function IntakeForm(){
  const [status, setStatus] = useState<string|null>(null);
  async function submit(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    const payload: IntakePayload = {
      name: String(data.name||''),
      email: String(data.email||''),
      phone: String(data.phone||''),
      location: String(data.location||''),
      birthdate: String(data.birthdate||''),
      intent: Array.from(document.querySelectorAll('input[name=intent]:checked')).map(i=>(i as HTMLInputElement).value) as any,
      spaceType: String(data.spaceType||'Home') as any,
      placement: String(data.placement||''),
      dimensions: String(data.dimensions||''),
      materials: Array.from(document.querySelectorAll('input[name=materials]:checked')).map(i=>(i as HTMLInputElement).value),
      geometry: Array.from(document.querySelectorAll('input[name=geometry]:checked')).map(i=>(i as HTMLInputElement).value),
      budget: String(data.budget||''),
      timeframe: String(data.timeframe||''),
      notes: String(data.notes||'')
    };
    const res = await fetch('/api/lead', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    setStatus(res.ok ? 'Thanks — we received your blueprint. We will follow up shortly.' : 'Something went wrong.');
    (e.target as HTMLFormElement).reset();
  }
  return (
    <form onSubmit={submit} className="card p-6 grid gap-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div><label className="block text-sm mb-1">Name</label><input name="name" required className="w-full rounded-lg bg-zinc-800 border-zinc-700" /></div>
        <div><label className="block text-sm mb-1">Email</label><input name="email" type="email" required className="w-full rounded-lg bg-zinc-800 border-zinc-700" /></div>
        <div><label className="block text-sm mb-1">Phone</label><input name="phone" className="w-full rounded-lg bg-zinc-800 border-zinc-700" /></div>
        <div><label className="block text-sm mb-1">Location (City, State)</label><input name="location" className="w-full rounded-lg bg-zinc-800 border-zinc-700" /></div>
        <div><label className="block text-sm mb-1">Birthdate</label><input name="birthdate" type="date" className="w-full rounded-lg bg-zinc-800 border-zinc-700" /></div>
      </div>

      <div>
        <label className="block text-sm mb-2">Intent</label>
        <div className="grid md:grid-cols-3 gap-2 text-sm">
          {['Wealth','Healing','Clarity','Protection','Legacy','Other'].map(x=> (
            <label key={x} className="inline-flex items-center gap-2">
              <input type="checkbox" name="intent" value={x} className="rounded border-zinc-700 bg-zinc-800" /> {x}
            </label>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm mb-1">Space Type</label>
          <select name="spaceType" className="w-full rounded-lg bg-zinc-800 border-zinc-700">
            {['Home','Office','Studio','Hospitality','Sacred Space'].map(x=> <option key={x}>{x}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1">Placement</label>
          <select name="placement" className="w-full rounded-lg bg-zinc-800 border-zinc-700">
            {['Dining','Office','Entry','Meditation','Wall','Lighting','Other'].map(x=> <option key={x}>{x}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1">Approx. Dimensions / Area</label>
          <input name="dimensions" className="w-full rounded-lg bg-zinc-800 border-zinc-700" placeholder="e.g., 84&quot; x 40&quot; top" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <div className="text-sm mb-2">Materials</div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {['Walnut','Cedar','Oak','Ebony','Copper','Gold','Silver','Brass','Quartz','Selenite','Tourmaline','Amethyst','Citrine','Malachite','Resin'].map(x=> (
              <label key={x} className="inline-flex items-center gap-2">
                <input type="checkbox" name="materials" value={x} className="rounded border-zinc-700 bg-zinc-800" /> {x}
              </label>
            ))}
          </div>
        </div>
        <div>
          <div className="text-sm mb-2">Geometry</div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {['Circle','Octagon','Hexagon','Phi Spiral','3-6-9','Vesica','Flower of Life'].map(x=> (
              <label key={x} className="inline-flex items-center gap-2">
                <input type="checkbox" name="geometry" value={x} className="rounded border-zinc-700 bg-zinc-800" /> {x}
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm mb-1">Budget</label>
          <select name="budget" className="w-full rounded-lg bg-zinc-800 border-zinc-700">
            {['<$2k','$2k–$5k','$5k–$10k','$10k–$25k','$25k+'].map(x=> <option key={x}>{x}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1">Desired Timeline</label>
          <select name="timeframe" className="w-full rounded-lg bg-zinc-800 border-zinc-700">
            {['ASAP','2–4 weeks','1–2 months','3+ months'].map(x=> <option key={x}>{x}</option>)}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm mb-1">Notes / Vision</label>
        <textarea name="notes" rows={4} className="w-full rounded-lg bg-zinc-800 border-zinc-700" placeholder="Tell us about your space, intention, and any inspiration links..."></textarea>
      </div>

      <button className="btn w-full md:w-auto" type="submit">Send Blueprint</button>
      {status && <div className="text-sm text-stone-300">{status}</div>}
    </form>
  );
}
