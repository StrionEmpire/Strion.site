
export function Section({title, subtitle, children}:{title:string; subtitle?:string; children:React.ReactNode}){
  return (
    <section className="section">
      <h2 className="h2">{title}</h2>
      {subtitle && <p className="lead mt-2">{subtitle}</p>}
      <div className="mt-8">{children}</div>
    </section>
  );
}
