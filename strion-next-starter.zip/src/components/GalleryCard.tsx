
import Image from 'next/image';
export function GalleryCard({title, src, caption}:{title:string; src:string; caption:string}){
  return (
    <figure className="card overflow-hidden">
      <Image src={src} alt={title} width={1600} height={1000} className="w-full h-64 object-cover" />
      <figcaption className="p-4">
        <div className="font-semibold">{title}</div>
        <div className="text-stone-400 text-sm">{caption}</div>
      </figcaption>
    </figure>
  );
}
