
import { Section } from "@/components/Section";
export default function Page(){ return (<Section title="About Strion" subtitle="We bridge geometry, energy, and mastery."><div className='card p-6'><p className='text-stone-300'>Replace with real content.</p></div></Section>); }
