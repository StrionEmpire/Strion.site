
import { Section } from "@/components/Section";
export default function Page(){ return (<Section title="Contact" subtitle="Request a quote, book a consultation, or ask a question."><div className='card p-6'><p className='text-stone-300'>Replace with real content.</p></div></Section>); }
