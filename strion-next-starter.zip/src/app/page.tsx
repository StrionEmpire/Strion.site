
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { GalleryCard } from "@/components/GalleryCard";

export default function Page() {
  return (
    <>
      <Hero />
      <Section title="Featured Work" subtitle="Signature builds that embody resonance, mastery, and legacy.">
        <div className="grid md:grid-cols-3 gap-6">
          <GalleryCard title="Resonance Table" src="/renders/resonance-table.png" caption="Live-edge walnut, epoxy river, copper veins, quartz center." />
          <GalleryCard title="Abundance Octagon" src="/renders/octagon-table.png" caption="Walnut octagon with gold inlays and citrine medallion." />
          <GalleryCard title="Selenite Wall Light" src="/renders/selenite-light.png" caption="Stacked selenite rods in a brass frame with ambient halo." />
        </div>
      </Section>
      <Section title="The Strion Method" subtitle="Consultation → Energetic Mapping → Design → Build → Activation → Delivery">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="card p-6"><div className="font-semibold">Energetic Intake</div><p className="text-stone-400 mt-2 text-sm">Numerology, geometry, materials, and intention — aligned to your space.</p></div>
          <div className="card p-6"><div className="font-semibold">Precision Craft</div><p className="text-stone-400 mt-2 text-sm">Woods, metals, and crystals formed in sacred proportion and flow.</p></div>
          <div className="card p-6"><div className="font-semibold">Activation</div><p className="text-stone-400 mt-2 text-sm">Final alignment and care guidance for long-term resonance.</p></div>
        </div>
      </Section>
    </>
  );
}
