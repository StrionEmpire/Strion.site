
import { Section } from "@/components/Section";
import IntakeForm from "@/components/IntakeForm";
export default function Page(){ return (<Section title="Custom Builds" subtitle="Tell us about your space and intention — we’ll blueprint a build aligned to your goals."><IntakeForm/></Section>); }
