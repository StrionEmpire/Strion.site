
import { Section } from "@/components/Section";
export default function Page(){ return (<Section title="Work" subtitle="Tables, wall pieces, lighting, and architectural commissions."><div className='card p-6'><p className='text-stone-300'>Replace with real content.</p></div></Section>); }
